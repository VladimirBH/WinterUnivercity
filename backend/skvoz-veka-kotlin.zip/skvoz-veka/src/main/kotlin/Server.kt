import com.sun.net.httpserver.HttpExchange
import com.sun.net.httpserver.HttpServer
import java.net.InetSocketAddress
import java.util.concurrent.Executors

private const val church = "/api/v1/monuments/tserkov-lazarya"
private val routes = mapOf(
    "/api/v1/map" to "api/map.json",
    church to "api/card.json",
    "$church/comparison" to "api/comparison.json",
    "$church/source" to "api/source.json",
    "$church/ar" to "api/ar.json",
    "/media/today.jpg" to "media/today.jpg",
    "/media/reconstruction.jpg" to "media/reconstruction.jpg",
    "/media/drawing.jpg" to "media/drawing.jpg",
    "/media/sign.jpg" to "media/sign.jpg"
)

private data class Payload(val bytes: ByteArray, val type: String)

private fun HttpExchange.reply(status: Int, payload: Payload) {
    responseHeaders.set("Content-Type", payload.type)
    if (requestMethod == "HEAD") {
        responseHeaders.set("Content-Length", payload.bytes.size.toString())
        sendResponseHeaders(status, -1)
    } else {
        sendResponseHeaders(status, payload.bytes.size.toLong())
        responseBody.use { it.write(payload.bytes) }
    }
}

private fun errorBody(message: String) =
    Payload("""{"error":"$message"}""".toByteArray(), "application/json; charset=utf-8")

fun main() {
    val assets = routes.mapValues { (_, file) ->
        val stream = checkNotNull(Payload::class.java.getResourceAsStream("/$file")) { "Missing $file" }
        val bytes = stream.use { it.readBytes() }
        val type = if (file.endsWith(".jpg")) "image/jpeg" else "application/json; charset=utf-8"
        Payload(bytes, type)
    }
    val port = (System.getenv("PORT") ?: "8080").toInt()
    require(port in 1..65535) { "PORT must be between 1 and 65535" }
    val server = HttpServer.create(InetSocketAddress(System.getenv("HOST") ?: "127.0.0.1", port), 64)
    val pool = Executors.newFixedThreadPool(4)
    server.executor = pool
    server.createContext("/") { request ->
        try {
            request.responseHeaders.set("Access-Control-Allow-Origin", "*")
            val asset = assets[request.requestURI.rawPath]
            when {
                asset == null -> request.reply(404, errorBody("not_found"))
                request.requestMethod == "OPTIONS" -> {
                    request.responseHeaders.set("Access-Control-Allow-Methods", "GET, HEAD, OPTIONS")
                    request.sendResponseHeaders(204, -1)
                }
                request.requestMethod in setOf("GET", "HEAD") -> request.reply(200, asset)
                else -> {
                    request.responseHeaders.set("Allow", "GET, HEAD, OPTIONS")
                    request.reply(405, errorBody("method_not_allowed"))
                }
            }
        } finally {
            request.close()
        }
    }
    Runtime.getRuntime().addShutdownHook(Thread {
        server.stop(1)
        pool.shutdown()
    })
    server.start()
    println("Сквозь века: http://${server.address.hostString}:$port/api/v1/map")
}
